package com.example.mainapp.ui.profiles;

import android.arch.lifecycle.ViewModelProviders;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.mainapp.MainActivity;
import com.example.mainapp.R;
import com.example.mainapp.ui.scanner.ScannerViewModel;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;

public class AddFragment extends Fragment {

    EditText name,    //name
            mail,      //surname
            num,      //number
            work;     //profession
    ImageView prof; //photo
    FloatingActionButton yes;
    FloatingActionButton no;

    //Supporting
//    ImageView qr;     //personal qr-sode

    static public Bitmap bitmap;
    public static final int SIZE = 350, //QR-code size
            image = 1,
            camera = 0x0000c0de;;
    public static String res;       //Stroke for final data
    static String info = "";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_add, null);
        yes = root.findViewById(R.id.yes);
        no = root.findViewById(R.id.no);

        name = (EditText) root.findViewById(R.id.name);
        mail = (EditText) root.findViewById(R.id.mail);
        num = (EditText) root.findViewById(R.id.number);
        work = (EditText) root.findViewById(R.id.work);

        no.setOnClickListener(noOnClick());
        yes.setOnClickListener(yesOnClick());

//        qr.setOnClickListener(qrClick());
        return root;
    }

    private View.OnClickListener yesOnClick() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!name.getText().toString().isEmpty() && !num.getText().toString().isEmpty()) {
                    res = name.getText().toString() + "\n" +    //Convert all parameters into text
                            num.getText().toString() + "\n" +
                            mail.getText().toString() + "\n" +
                            work.getText().toString();
//                    bitmap = TextToImageEncode(res);            //Con
//                    qr.setImageBitmap(bitmap);
                    ProfilesFragment letter = new ProfilesFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("info", res);
                    letter.setArguments(bundle);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.nav_host_fragment, letter).commit();
                } else {
                    name.requestFocus();
                    num.requestFocus();
                    Toast.makeText(getContext(),
                            "Input your name and phone number",
                            Toast.LENGTH_SHORT).show();
                }
//                getFragmentManager().beginTransaction().replace(R.id.nav_host_fragment, new ProfilesFragment()).commit();
            }
        };
    }
    private View.OnClickListener noOnClick() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.nav_host_fragment, new ProfilesFragment()).commit();
            }
        };
    }

//    private View.OnClickListener qrClick() {
//        return new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (!name.getText().toString().isEmpty() && !num.getText().toString().isEmpty()) {
//                    res = name.getText().toString() + "\n" +    //Convert all parameters into text
//                            num.getText().toString() + "\n" +
//                            mail.getText().toString() + "\n" +
//                            work.getText().toString();
//                    bitmap = TextToImageEncode(res);            //Con
//                    qr.setImageBitmap(bitmap);
//                } else {
//                    name.requestFocus();
//                    num.requestFocus();
//                    Toast.makeText(getContext(),
//                            "Input your name and phone number",
//                            Toast.LENGTH_SHORT).show();
//                }
//            }
//        };
//    }
//
//    private Bitmap TextToImageEncode(String res) {
//        BitMatrix bitMatrix;
//        try {
//            bitMatrix = new MultiFormatWriter().encode(
//                    res,
//                    BarcodeFormat.QR_CODE,
//                    SIZE,
//                    SIZE,
//                    null);
//        } catch (WriterException e) { return null; }
//
//        int col = bitMatrix.getWidth();
//        int row = bitMatrix.getHeight();
//        int[] pixels = new int[col * row];
//
//        for (int i = 0; i < row; i++) {
//            int offset = i * col;
//            for (int j = 0; j < col; j++) {
//                pixels[offset + j] = bitMatrix.get(j, i) ?
//                        getResources().getColor(R.color.Black) :
//                        getResources().getColor(R.color.White);
//            }
//        }
//        Bitmap bit = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888);
//        bit.setPixels(pixels, 0, SIZE, 0, 0, col, row);
//        return bit;
//    }

}


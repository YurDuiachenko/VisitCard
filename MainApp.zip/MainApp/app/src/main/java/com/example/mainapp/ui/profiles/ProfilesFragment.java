package com.example.mainapp.ui.profiles;

import android.content.ContentProviderOperation;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.widget.Toast;

import com.example.mainapp.MainActivity;
import com.example.mainapp.OnSwipeTouchListener;
import com.example.mainapp.Person;
import com.example.mainapp.PersonAdapter;
import com.example.mainapp.R;
import com.example.mainapp.vCard;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ProfilesFragment extends Fragment {

    public static final int SIZE = 350;
    String info;
    FloatingActionButton fab;
    FragmentTransaction fragmentTransaction;
    Fragment addFragment;
    //the recyclerview
    RecyclerView recyclerView;
    private ProfilesViewModel profilesViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        profilesViewModel =
                ViewModelProviders.of(this).get(ProfilesViewModel.class);
        View root = inflater.inflate(R.layout.fragment_profiles, container, false);
        setHasOptionsMenu(true);
        Toolbar toolbar = (Toolbar) root.findViewById(R.id.toolbar);
        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);

        recyclerView = (RecyclerView) root.findViewById(R.id.r);
        recyclerView.setHasFixedSize(false);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        addFragment = new AddFragment();
        fab = (FloatingActionButton) root.findViewById(R.id.fab);
        fab.setOnClickListener(fabOnClick());

        Bundle bundle = getArguments();
        if (bundle != null) {
            info = bundle.getString("info");
            HashMap<String, String> data = vCard.readRes(info);
            MainActivity.personList.add(
                    new Person(
                            data.get("name"),
                            data.get("phone"),
                            data.get("email"),
                            data.get("work"),
                            TextToImageEncode(info)
                    )
            );
        }

        PersonAdapter adapter = new PersonAdapter(getContext(), MainActivity.personList);
        recyclerView.setAdapter(adapter);
        return root;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_scrolling, menu) ;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private View.OnClickListener fabOnClick() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.nav_host_fragment, addFragment).commit();
            }
        };
    }

    public Bitmap TextToImageEncode(String res) {
        BitMatrix bitMatrix;
        try {
            bitMatrix = new MultiFormatWriter().encode(
                    res,
                    BarcodeFormat.QR_CODE,
                    SIZE,
                    SIZE,
                    null);
        } catch (WriterException e) { return null; }

        int col = bitMatrix.getWidth();
        int row = bitMatrix.getHeight();
        int[] pixels = new int[col * row];

        for (int i = 0; i < row; i++) {
            int offset = i * col;
            for (int j = 0; j < col; j++) {
                pixels[offset + j] = bitMatrix.get(j, i) ?
                        getResources().getColor(R.color.Black) :
                        getResources().getColor(R.color.White);
            }
        }
        Bitmap bit = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888);
        bit.setPixels(pixels, 0, SIZE, 0, 0, col, row);
        return bit;
    }
}


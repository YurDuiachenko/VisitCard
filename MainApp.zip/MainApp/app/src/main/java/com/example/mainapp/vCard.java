package com.example.mainapp;

import android.content.ContentProviderOperation;
import android.provider.ContactsContract;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.time.chrono.MinguoDate;
import java.util.ArrayList;
import java.util.HashMap;

public class vCard {
    //Матвей, смари в чём мем: мы вписываем энто дело в файл vCard с помощью методов ниже
    //Но я подумал: а не легче ли будет вписывать в обычный txt? не быстрее ли?
    //Переделкой энтого класса займусь позже

    public static void write(HashMap<String, String> data, String path) throws IOException {
        File f = new File(path);
        FileOutputStream fop = new FileOutputStream(f);
        String str = "BEGIN:VCARD" + "\n" +
                "NAME:" + data.get("NAME") + "\n" +
                "VERSION:" + data.get("VERSION") + "\n" +
                "N:" + data.get("N") + "\n" +
                "FN:" + data.get("FN") + "\n" +
                "TEL:" + data.get("TEL") + "\n" +
                "EMAIL:" + data.get("EMAIL") + "\n" +
                "URL:" + data.get("URL") + "\n" +
                "TEXT:" + data.get("TEXT") + "\n" +
                "END:VCARD";
        fop.write(str.getBytes());
        BufferedReader br = null;
        String sCurrentLine;
        br = new BufferedReader(new FileReader(path));
        fop.flush();
        fop.close();
    }

    public static ArrayList<ContentProviderOperation> addNewStandardContact(String name, String phone, String email, String work) {
        ArrayList<ContentProviderOperation> op = new ArrayList<ContentProviderOperation>();
        // Добавляем пустой контакт
        op.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build());
        // Добавляем данные имени
        op.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                .build());
        // Добавляем данные телефона
        op.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                .build());
        // Добавляем данные почты
        op.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, email)
                .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, email)
                .build());
        // Добавляем данные работы
        op.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Organization.JOB_DESCRIPTION, work)
                .withValue(ContactsContract.CommonDataKinds.Organization.JOB_DESCRIPTION, work)
                .build());
        return op;
    }

    public static HashMap<String, String> readRes(String res) {
        HashMap<String, String> data = new HashMap<>();
        char[] l = new char[res.indexOf("\n")];
        res.getChars(0, res.indexOf("\n"), l, 0);
        String name = "";
        for (int i = 0; i < l.length; i++) {
            name = name + l[i];
        }
        data.put("name", name);

        String res1 = "";
        l = new char[res.length() - res.indexOf("\n")];
        res.getChars(res.indexOf("\n")+1, res.length(), l, 0);
        for (int i = 0; i < l.length; i++) {
            res1 = res1 + l[i];
        }
        res = res1;

        l = new char[res.indexOf("\n")];
        res.getChars(0, res.indexOf("\n"), l, 0);
        name = "";
        for (int i = 0; i < l.length; i++) {
            name = name + l[i];
        }
        data.put("phone", name);

        l = new char[res.length() - res.indexOf("\n")];
        res.getChars(res.indexOf("\n") + 1, res.lastIndexOf("\n"), l, 0);
        name = "";
        for (int i = 0; i < l.length; i++) {
            name = name + l[i];
        }
        data.put("email", name);

        l = new char[res.length() - res.indexOf("\n")];
        res.getChars(res.lastIndexOf("\n") + 1, res.length(), l, 0);
        name = "";
        for (int i = 0; i < l.length; i++) {
            name = name + l[i];
        }
        data.put("work",name);
        return data;
    }

}

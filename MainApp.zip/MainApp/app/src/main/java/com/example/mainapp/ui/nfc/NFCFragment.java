package com.example.mainapp.ui.nfc;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;

import com.example.mainapp.R;
import com.example.mainapp.ui.nfc.NFCViewModel;

public class NFCFragment extends Fragment {
    FloatingActionButton fab;
    private NFCViewModel nfcViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        nfcViewModel =
                ViewModelProviders.of(this).get(NFCViewModel.class);
        View root = inflater.inflate(R.layout.fragment_nfc, container, false);


        return root;
    }
}

package com.example.mainapp;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;


public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.PersonViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<Person> personList;

    //getting the context and product list with constructor
    public PersonAdapter(Context mCtx, List<Person> personList) {
        this.mCtx = mCtx;
        this.personList = personList;
    }

    @Override
    public PersonViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.layout_person, null);
        return new PersonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PersonViewHolder holder, int position) {
        //getting the product of the specified position
        Person person = personList.get(position);
        holder.name.setText(person.getName());
        holder.email.setText(person.getPhone());
        holder.phone.setText(String.valueOf(person.getMail()));
        holder.work.setText(String.valueOf(person.getWork()));
        holder.qr.setImageBitmap(person.getImage());

    }


    @Override
    public int getItemCount() {
        return personList.size();
    }


    class PersonViewHolder extends RecyclerView.ViewHolder {

        TextView name, phone, email, work;
        ImageView qr;

        public PersonViewHolder(View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            phone = itemView.findViewById(R.id.phone);
            email = itemView.findViewById(R.id.email);
            work = itemView.findViewById(R.id.work);
            qr = itemView.findViewById(R.id.qr);
        }
    }
}

package com.example.mainapp.ui.profiles;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class ProfilesViewModel extends ViewModel {

    public ProfilesViewModel() {
    }
}
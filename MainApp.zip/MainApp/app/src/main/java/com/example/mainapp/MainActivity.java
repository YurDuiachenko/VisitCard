package com.example.mainapp;

import android.Manifest;
import android.content.ContentProviderOperation;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.mainapp.ui.profiles.ProfilesFragment;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static List<Person> personList ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);


        ///////////////////////////////
        try{
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_CONTACTS,
                            Manifest.permission.CAMERA,
                            Manifest.permission.READ_CONTACTS,
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.NFC,
                            Manifest.permission.NFC_TRANSACTION_EVENT,
                            Manifest.permission.READ_PHONE_NUMBERS},
                    PackageManager.PERMISSION_GRANTED );
        } catch (Exception e) {
            e.printStackTrace();
        }
        /////////////////////////////

        /////////////////////////////
        personList = new ArrayList<>();
//        personList.add(
//                new Person(
//                        "Yuri",
//                        "+79102588486",
//                        "d.yurok22@mail.ru",
//                        "Android-Developer",
//                        new ProfilesFragment().TextToImageEncode(
//                                "Yuri Diachenko" + "\n" +
//                                        "+79102588486" + "\n" +
//                                        "d.yurok22@mail.ru"  + "\n" +
//                                        "Android-Developer")
//                )
//        );
        ///////////////////////////////


        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupWithNavController(navView, navController);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Log.i("Scan", "Scanner didn't has an information");
            } else {
                Log.i("Scan", "Scanned");
                String all = result.getContents();

                char[] to = new char[all.indexOf("\n")];
                all.getChars(0, all.indexOf("\n"), to, 0);
                String notarial = String.valueOf(to);

                char[] ot = new char[all.length() - all.indexOf("\n")];
                all = delete(all, 0, all.indexOf("\n") + 1);
                all.getChars(0, all.indexOf("\n"), ot, 0);
                String phone = String.valueOf(ot);

                all = delete(all, 0, all.indexOf("\n") + 1);
                char[] t = new char[all.length()];
                all.getChars(0, all.indexOf("\n"), t, 0);
                String email = String.valueOf(t);

                String job = delete(all, 0, all.indexOf("\n") + 1);

                ArrayList<ContentProviderOperation> now = vCard.addNewStandardContact(notarial, phone, email, job);
                try {
                    getBaseContext().getContentResolver().applyBatch(ContactsContract.AUTHORITY, now);
                } catch (Exception e) {
                    Log.e("Exception: ", e.getMessage());
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    static String delete(String str, int from, int to) {
        return str.substring(0,from)+str.substring(to);
    }
}

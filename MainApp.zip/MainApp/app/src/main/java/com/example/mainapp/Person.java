package com.example.mainapp;

import android.graphics.Bitmap;

import java.util.List;

public class Person {
    String name,
            phone,
            mail,
            work;
    Bitmap qr;

    public Person(String name, String phone, String mail, String work, Bitmap qr) {
        this.name = name;
        this.phone = phone;
        this.mail = mail;
        this.work = work;
        this.qr = qr;
    }

    private List<Person> persons;

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getMail() {
        return mail;
    }

    public String getWork() {
        return work;
    }

    public Bitmap getImage() {
        return qr;
    }

}
